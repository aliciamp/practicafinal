export class ContactModel {
    _id:string | undefined;
    name: string | undefined;
    surname: string | undefined;
    age: number | undefined;
    dni: string | undefined;
    birthday: string | undefined;
    color: string | undefined;
    gender: string | undefined;
};